# 从 GitHub 构建与安装最新版本

本文是万落建筑工具唯一的发布流程。不要运行仓库根目录、`CadApi`、旧安装包目录或聊天测试过程中生成的 EXE/DLL；这些位置可能是旧版本。

## 1. 拉取最新代码

关闭 AutoCAD 后，在仓库目录执行：

```powershell
git pull --ff-only
git status --short
```

正式发布前，`git status --short` 应为空。若有本地修改，先确认、提交或备份，不要直接覆盖。

## 2. 编译环境

需要：

- Visual Studio Build Tools（含 MSBuild）。
- .NET Framework 4.8 或 4.8.1 Targeting Pack。
- 编译 AutoCAD 2025–2026（R25）时需要 .NET 8 SDK。
- 本机至少安装一个 AutoCAD 2021–2026，脚本会从固定磁盘及 Autodesk 注册表查找，包括非默认安装目录。

推荐把 .NET 8 安装为系统 SDK。也可以把便携 SDK 放在仓库的 `.tools\dotnet`；该目录不会提交到 GitHub。

## 3. 唯一发布命令

```powershell
powershell -ExecutionPolicy Bypass -File .\build\Build-Release.ps1
```

脚本默认编译本机能提供 SDK 的全部 AutoCAD API 代际。也可以明确指定：

```powershell
.\build\Build-Release.ps1 -Bands R24,R25
```

本机装有 AutoCAD 2022 时，R24 默认使用它的 API；没有 2022 时使用已安装的最新 R24 API。要明确指定 AutoCAD 2022，可执行：

```powershell
.\build\Build-Release.ps1 -Bands R24,R25 -R24AutoCadYear 2022
```

指定的 AutoCAD 版本必须已安装；该参数只选择编译引用，运行仍需在目标 CAD 版本中验证。

正式用户包需要同时携带免安装 Python 的 PaddleOCR 增强组件时执行：

```powershell
.\build\Build-Release.ps1 -Bands R24,R25 -IncludePaddleOcr
```

该组件约 650 MB，只在发布根目录 `OcrEngine` 保存一份，不会在 R24/R25 目录中重复。构建机需要先按 `LineVisionPaddleOcrWorker\README.md` 准备固定版本的隔离构建环境和模型；用户电脑不需要 Python，也不会在识别时临时下载模型。

需要单独发布、供用户在“图像转 CAD → 管理增强组件”中按需安装时执行：

```powershell
.\build\Build-PaddleOcrUserPackage.ps1
```

输出为 `dist\OptionalComponents\WanLuo-PaddleOCR-3.7.0.zip` 及对应 `.sha256` 文件。将 ZIP 作为 GitHub Release 资产发布后，插件可在线发现并校验 GitHub 提供的 SHA256 摘要；也可把同一 ZIP 交给用户离线安装。

版本分组为：

| 目录 | AutoCAD 版本 |
|---|---|
| R24 | 2021–2024 |
| R25 | 2025–2026 |

每次执行都会先删除旧发布目录，再从当前源码重新生成。唯一可安装目录是：

```text
dist\WanLuoArchitectureTools\
```

只能运行其中的：

```text
万落建筑工具启动器.exe
```

## 4. 如何确认是最新版本

发布目录中的 `build-info.json` 记录：

- 构建时间；
- Git 分支和提交号；
- 构建时工作区是否有未提交修改；
- 启动器及各 CAD 代际插件 DLL 的 SHA-256。
- 是否包含 PaddleOCR，以及其入口程序 SHA-256。

用以下命令比较当前提交：

```powershell
git rev-parse HEAD
Get-Content .\dist\WanLuoArchitectureTools\build-info.json
```

正式交付时，两个提交号应一致，且 `GitDirty` 应为 `false`。发布目录中不会包含带 `fix`、日期、`test` 等后缀的历史 DLL；每个 `CadApi\Rxx` 只使用正式的 `BatchPdfPublisher.dll`。

启动器的“项目管理”与主插件共用同一份项目读写逻辑，但**不新增 DLL**：这些源文件由
`BatchPdfPublisherLauncher.csproj` 以 `<Compile Include="..\BatchPdfPublisher\…">` 源码链接方式编译
（与 `Shared\ProductVersion.cs` 同一做法），因此安装清单、自动加载清单和上面的 DLL 白名单校验都不需要改。
代价是：改动这些共享文件会同时影响主插件与启动器，新增共享文件必须同时补进启动器的 `Compile` 清单
（清单见 [功能模块与快捷键](MODULES_AND_SHORTCUTS.md) 末尾）。

## 5. 安装与更新

1. 关闭全部 AutoCAD/天正进程，避免旧 DLL 被占用。
2. 运行 `dist\WanLuoArchitectureTools\万落建筑工具启动器.exe`。
3. 选择检测到的 AutoCAD 或“天正产品 + AutoCAD”组合。
4. 便携使用时直接从发布目录加载；选择永久安装时，启动器更新 AutoCAD 的 ApplicationPlugins 包。
5. 更新 GitHub 代码后必须重新执行发布命令，再运行新发布目录中的启动器。不要复用旧压缩包或旧安装目录。

天正和 AutoCAD 可以安装在任意磁盘；启动器依据安装信息和实际可执行文件探测，不依赖本机固定路径。

## 6. 清理开发目录

先预览将删除的内容：

```powershell
.\build\Clean-Workspace.ps1 -WhatIf
```

确认后执行：

```powershell
.\build\Clean-Workspace.ps1
```

它只删除仓库内部可再生成的文件，包括旧 `CadApi`、根目录 DLL/EXE/PDB、测试日志、临时脚本、旧安装包、解压出来的重复组件和中间编译目录；不会删除 `dist`、源码、用户工程、DWG 或用户参数。

## 7. 仓库目录约定

```text
BatchPdfPublisher/                 主 CAD 插件源码
BatchPdfPublisherLauncher/         启动器源码及内嵌组件包
CadArchSpecEditor/                 建筑设计说明助手源码与资源
Resources/                         DWG、PC3、PMP 等运行资源
build/                             构建、兼容和清理脚本
docs/                              当前说明、历史记录和规划
dist/                              本机发布结果（不提交）
```

禁止提交：编译输出、PDB、临时 DLL、旧安装包、测试日志、本机 SDK、解压出的重复源码或组件。运行资源若要随安装器发布，应放入对应源码的 `Payload` 或 `Resources` 并由项目文件显式嵌入。

`build\Build-Compatibility.ps1` 是需要完整 Autodesk SDK 矩阵时使用的高级构建入口；日常从 GitHub 拉取后安装，应使用 `build\Build-Release.ps1`。
